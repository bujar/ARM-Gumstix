/* btagani, jlim2, luow
 * hello.c
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("Hello, world!\n");
	exit(0);
}
